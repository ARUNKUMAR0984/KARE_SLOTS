<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'NGM3MTUxNzc2NTM4NmE3NTc5NjU0NjYzMzY1ODMwNzM=');

	/*You can enter mobile number here*/
	define("MOBILE", '8015130984');
 ?>